import json
import os

import anthropic
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from prompts import (
    CRISIS_RESPONSE_TEXT,
    GUARDRAIL_SYSTEM_PROMPT,
    REFLECTOR_SYSTEM_PROMPT,
)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten before real deploy
    allow_methods=["*"],
    allow_headers=["*"],
)

client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))

MODEL = "claude-sonnet-4-6"


class EchoRequest(BaseModel):
    text: str


class EchoResponse(BaseModel):
    mode: str  # "reflection" | "crisis"
    text: str


@app.post("/echo", response_model=EchoResponse)
def echo(req: EchoRequest):
    user_text = req.text.strip()
    if not user_text:
        return EchoResponse(mode="reflection", text="")

    # 1. Guardrail check
    guardrail_msg = client.messages.create(
        model=MODEL,
        max_tokens=100,
        system=GUARDRAIL_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_text}],
    )
    raw = guardrail_msg.content[0].text.strip()
    try:
        # Strip potential code fences
        cleaned = raw.replace("```json", "").replace("```", "").strip()
        risk_data = json.loads(cleaned)
        risk = risk_data.get("risk", "safe")
    except Exception:
        # Fail safe: if parsing fails, err toward crisis response
        risk = "crisis"

    if risk == "crisis":
        return EchoResponse(mode="crisis", text=CRISIS_RESPONSE_TEXT)

    # 2. Reflector
    reflect_msg = client.messages.create(
        model=MODEL,
        max_tokens=150,
        system=REFLECTOR_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_text}],
    )
    reflection = reflect_msg.content[0].text.strip()
    return EchoResponse(mode="reflection", text=reflection)


@app.get("/health")
def health():
    return {"status": "ok"}
